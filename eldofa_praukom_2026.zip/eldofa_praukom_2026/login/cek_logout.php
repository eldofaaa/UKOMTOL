<?php
    session_start();

    include "../includes/index.php";
    session_destroy();
    header("location:".base_url."");
 ?>   