<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bootstrap-icons/bootstrap-icons.min.css">
  <title>Login page</title>
  <style>
    * {
      box-sizing: border-box;
      font-family: Arial, Helvetica, sans-serif;
    }

    body {
      margin: 0;
      min-height: 100vh;
      background: linear-gradient(135deg, #471108, #111);
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .login-container {
      background: #030101;
      padding: 32px;
      width: 100%;
      max-width: 400px;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }

    .login-container h1 {
      text-align: center;
      margin-bottom: 8px;
      color: #111827;
    }

    .login-container p {
      text-align: center;
      margin-bottom: 24px;
      color: #6b7280;
      font-size: 14px;
    }

    .form-group {
      margin-bottom: 16px;
    }

    label {
      display: block;
      margin-bottom: 6px;
      font-size: 14px;
      color: #374151;
    }

    input {
      width: 100%;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid #d1d5db;
      font-size: 14px;
    }

    input:focus {
      outline: none;
      border-color: #3b82f6;
      box-shadow: 0 0 0 2px rgba(59,130,246,0.2);
    }

    button {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 8px;
      background: #3b82f6;
      color: #ffffff;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      margin-top: 8px;
    }

    button:hover {
      background: #2563eb;
    }

    .footer-text {
      margin-top: 16px;
      text-align: center;
      font-size: 13px;
      color: #6b7280;
    }

    .footer-text a {
      color: #3b82f6;
      text-decoration: none;
      font-weight: 500;
    }
  </style>
</head>
<body>
     <!-- awal navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow">
        <div class="container">
            <a href="../index.php" class="navbar-brand fw-bold"><i class="bi bi-anthropic"></i>SPIRATION</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item fw-bold"><a href="" class="nav-link">feature</a></li>
                    <li class="nav-item fw-bold"><a href="" class="nav-link">about</a></li>
                    <li class="nav-item fw-bold"><a href="" class="btn btn-success text-light">register</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- akhir navbar -->
<!-- Login Section -->
<div class="container d-flex justify-content-center align-items-center" style="margin-top:80px;">
  <div class="card bg-black text-light shadow p-4 rounded-4" style="max-width:400px; width:100%;">

    <h1 class="text-center fw-bold mb-4">LOGIN</h1>

    <form action="cek_login.php" method="post">

      <div class="mb-3">
        <label for="email" class="form-label text-light">Email</label>
        <input type="email"
               class="form-control"
               id="email"
               name="email"
               placeholder="contoh@email.com"
               required>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label text-light">Password</label>
        <input type="password"
               class="form-control"
               id="password"
               name="password"
               placeholder="••••••••"
               required>
      </div>

      <button type="submit" class="btn btn-success w-100 fw-bold">
        Login
      </button>

    </form>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>