<?php
session_start();

include "../includes/koneksi.php";
$email   = $_POST['email'];
$password   = $_POST['password'];

$hash_password = md5($password);
//mengubah sandi menjadi hasil hash

$sql = "SELECT * FROM tb_user
        WHERE email='$email' 
        AND password='$hash_password'";
$sql_eksekusi = mysqli_query($koneksi, $sql);
$hitung = mysqli_num_rows($sql_eksekusi);
$data = mysqli_fetch_array($sql_eksekusi);
if ($hitung == 1) {
    $_SESSION['id_user'] = $data['id_user'];
    $_SESSION['nis'] = $data['nis'];
    $_SESSION['nama'] = $data['nama'];
    $_SESSION['role'] = $data['role'];
    header("location:../admin");
} else {
    header("location:index.php");
}
?>