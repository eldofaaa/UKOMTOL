<?php

    $server         = "localhost";
    $user           = "root";
    $password       = "";
    $database       = "db_aspirasi_praukom_2026";

    $koneksi = mysqli_connect($server, $user, $password) or die ("gagal terhubung dengan server");

    $db = mysqli_select_db($koneksi, $database) or die ("database tidak ditemukan");
?>