<?php
    $preurl = explode("/", $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
    $url = (isset($_SERVER['HTTPS'])?"https":"http")."://".$preurl[0]."/".$preurl[1]."/";
    define("base_url", $url);
?>