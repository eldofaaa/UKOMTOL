 <?php
    session_start();
    $_SESSION['menu'] = "kelas";
    include "../../includes/koneksi.php";
 ?>
 
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../bootstrap-icons/bootstrap-icons.min.css">
    <title>siswa</title>
 </head>
 <body>
    <!-- awal navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark  shadow mb-3">
        <div class="container">
            <a href="../index.php" class="navbar-brand fw-bold"><i class="bi bi-anthropic"></i>SPIRATION</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item fw-bold"><a href="" class="nav-link">aspirations</a></li>
                    <li class="nav-item fw-bold"><a href="kelas/index.php" class="nav-link">class</a></li>
                    <li class="nav-item fw-bold"><a href="" class="nav-link">student</a></li>
                    <li class="nav-item fw-bold"><a href="" class="nav-link">category</a></li>
                    <li class="nav-item fw-bold"><a href="" class="btn btn-danger text-light">log out</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- akhir navbar -->

     <!-- Ini tampilan untuk ADMIN -->
    <div class="container vh-custom">
        <hr>
        <!-- Awal Modal -->
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            add class
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">add class</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form action="input_kategori.php" method="post">
                            <div class="row">
                                <div class="col-12">
                                    <label for="" class="mt-2">class name</label>
                                    <input type="hidden" name="id_kategori" id="">
                                    <input type="text" name="nama_kategori" id="" class="form-control">
                                </div>
                                <div class="col-12">
                                    <label for="" class="mt-2">class desciption</label>
                                    <textarea name="ket_kategori" id="" class="form-control"></textarea>
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="submit" value="add" class="btn btn-primary">
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Akhir Modal -->
        <table class="table mt-3">
            <thead class="table-dark">
                <tr>
                    <th>Number</th>
                    <th>class </th>
                    <th>class description</th>
                    <th colspan='2'>action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM tb_kelas";
                $sql_eksekusi =  mysqli_query($koneksi, $sql);
                $nomor = 1;
                while ($data = mysqli_fetch_array($sql_eksekusi)) {
                    echo "<tr>";
                    echo "  <td>" . $nomor++ . "</td>";
                    echo "  <td>" . $data['nama_kelas'] . "</td>";
                    echo "  <td>" . $data['tahun_ajaran'] . "</td>";
                ?>
                    <td>
                        <!-- Awal Modal Ubah -->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalubah<?= $nomor; ?>">
                            change
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="modalubah<?= $nomor; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header bg-warning">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">ubah kategori</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">

                                        <form action="update_kategori.php" method="post">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label for="" class="mt-2">class name</label>
                                                    <input type="hidden" name="id_kategori" id="" value="<?= $data['id_kategori']; ?>">
                                                    <input type="text" name="nama_kategori" id="" class="form-control" value="<?= $data['nama_kategori']; ?>">
                                                </div>
                                                <div class="col-12">
                                                    <label for="" class="mt-2">class description</label>
                                                    <textarea name="ket_kategori" id="" class="form-control" required <?= $data['ket_kategori']; ?>></textarea>
                                                </div>
                                            </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <input type="submit" value="Simpan" class="btn btn-warning">
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Akhir Modal Ubah -->
                    </td>

                    <!-- Awal Modal Hapus -->
                    <!-- Button trigger modal -->
                    <td>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalhapus<?= $nomor; ?>">
                            Hapus
                        </button>
                    </td>

                    <!-- Modal -->
                    <div class="modal fade" id="modalhapus<?= $nomor; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-danger">
                                    <h1 class="modal-title fs-5 text-light" id="exampleModalLabel">Hapus Data</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Apakah anda yakin ingin menghapus kategori <b><?= $data['nama_kategori']; ?></b>?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    <a href="hapus_kategori.php?id_kategori=<?= $data['id_kategori']; ?>" class="btn btn-danger">Hapus</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Akhir Modal Hapus -->
                <?php
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <?php
            include "../../includes/footer.php";
        ?>
 </body>
 </html>