<?php
session_start();

if (!isset($_SESSION['role'])) {
    header("location:../index.php");
    if ($_SESSION['role'] != "admin") {
        header("location:../index.php");
    }
}
$_SESSION['menu'] = "beranda";

include "../includes/koneksi.php";
include "../includes/baseurl.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap-icons/bootstrap-icons.min.css">
    <title>admin page</title>
</head>

<body>
    <!-- awal navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark  shadow mb-3">
        <div class="container">
            <a href="../index.php" class="navbar-brand fw-bold"><i class="bi bi-anthropic"></i>SPIRATION</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item fw-bold"><a href="aspirasi" class="nav-link">aspirations</a></li>
                    <li class="nav-item fw-bold"><a href="kelas/index.php" class="nav-link">class</a></li>
                    <li class="nav-item fw-bold"><a href="siswa" class="nav-link">student</a></li>
                    <li class="nav-item fw-bold"><a href="kategory" class="nav-link">category</a></li>
                    <li class="nav-item fw-bold"><a href="" class="btn btn-danger text-light">log out</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- akhir navbar -->
    <div class="container">
        <div class="row">
            <div class="col-lg-3 mt-5">
                <div class="card rounded-4 shadow-sm">
                    <div class="card-body d-flex align-items-center gap-3">
                        <div class="bg-primary-subtle text-primary rounded-3 p-3">
                            <i class="bi bi-chat-dots fs-4"></i>
                        </div>
                    <div>
                        <small class="text-muted">aspirations total</small>
                        <h4 class="fw-bold md-0">1,590</h4>
                    </div>
                </div>
            </div>
        </div>

            <div class="col-lg-3 mt-5">
                <div class="card rounded-4 shadow-sm">
                    <div class="card-body d-flex align-items-center gap-3">
                        <div class="bg-warning-subtle text-warning rounded-3 p-3">
                            <i class="bi bi-houses fs-4"></i>
                        </div>
                    <div>
                        <small class="text-muted">class</small>
                        <h4 class="fw-bold md-0">50</h4>
                    </div>
                </div>
            </div>
        </div>

            <div class="col-lg-3 mt-5">
                <div class="card rounded-4 shadow-sm">
                    <div class="card-body d-flex align-items-center gap-3">
                        <div class="bg-success-subtle text-success rounded-3 p-3">
                            <i class="bi bi-backpack fs-4"></i>
                        </div>
                    <div>
                        <small class="text-muted">student</small>
                        <h4 class="fw-bold md-0">1,600</h4>
                    </div>
                </div>
            </div>
        </div>

           <div class="col-lg-3 mt-5">
                <div class="card rounded-4 shadow-sm">
                    <div class="card-body d-flex align-items-center gap-3">
                        <div class="bg-info-subtle text-info rounded-3 p-3">
                            <i class="bi bi-blockquote-right fs-4"></i>
                        </div>
                    <div>
                        <small class="text-muted">category total</small>
                        <h4 class="fw-bold md-0">1,105</h4>
                    </div>
                </div>
            </div>
        </div>
</div>

</body>

</html>