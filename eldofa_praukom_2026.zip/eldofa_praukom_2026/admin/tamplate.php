<?php
    session_start();

    // pengecekan jika tidak asa session role atau rolenya
    // maka di kick ke halaman landing page
    if(!isset($_SESSION['role']) || $_SESSION['role'] !="admin" )








?>

        <main class="flex-fill">
        <div class="container py-3">
             <h5>manajemen kelas</h5><hr>
             <table class="table">
                <thead>
                    <tr>
                        <th>nama kelas</th>
                        <th>tahun ajaran</th>
                        <th>waktu dibuat</th>
                        <th>tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $sql = "SELECT * FROM tb_kelas";
                        $sql_eksekusi = mysqli_query($koneksi, $sql);
                        while($data = mysqli_fetch_array($sql_eksekusi))
                            {
                    ?>            
                                <tr>
                                    <td><?= $data['nama_kelas']; ?></td>
                                    <td><?= $data['tahu_ajaran']; ?></td>
                                    <td><?= $data['created_at']; ?></td>
                                    <td>ubah</td>
                                    <td>hapus</td>
                                </tr>
                            
                            <?php 
                            }
                            ?>
                </tbody>
             </table>
        </div>
        </main>
